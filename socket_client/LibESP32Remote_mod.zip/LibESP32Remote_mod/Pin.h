#ifndef Remote_Pin_h
#define Remote_Pin_h

//Struct que será enviada entre o client e o server
typedef struct 
{
    int number;
    int status;
} Pin;

#endif